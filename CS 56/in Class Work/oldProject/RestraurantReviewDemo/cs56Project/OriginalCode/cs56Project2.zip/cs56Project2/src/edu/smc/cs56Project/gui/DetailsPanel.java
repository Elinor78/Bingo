/*
 * CS56 Advanced Java
 * Class: DetailsPanel
 * Author(s): Heather Ruderian
 * LAST UPDATE: 5-22-07
 *
 * Purpose: Displays restaurant details including picture, name, location, 
 * contact information, food type, rating, and brief review. 
 * 
 */

package edu.smc.cs56Project.gui;

import javax.swing.JPanel;
import javax.swing.JTextField;
import java.awt.FlowLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Rectangle;

public class DetailsPanel extends JPanel {
    private JTextField detailsTextField;
    
    // DetailsPanel constructor
    public DetailsPanel()
    {
        super();
        initialize();
    }
    
    // Initialize DetailsPanel and add components
    private void initialize()
    {
        this.setLayout( new FlowLayout() );
        this.setPreferredSize( new Dimension( 200, 800 ) );
        this.setBounds( new Rectangle( 0, 0, 200, 800 ) );
        this.setBackground(new Color(255, 255, 204));
        this.add( getDetailsTextField() );
        this.validate();
    }
    
    private JTextField getDetailsTextField()
    {
        if (detailsTextField == null) {
            detailsTextField = new JTextField();
            detailsTextField.setEditable(false);
            detailsTextField.setFont(new Font("Arial", Font.PLAIN, 14));
            detailsTextField.setText("This is the Details Panel");
            detailsTextField.addCaretListener(new javax.swing.event.CaretListener() {
                public void caretUpdate( javax.swing.event.CaretEvent e )
                {
                    System.out.println("caretUpdate()"); // TODO Auto-generated Event stub caretUpdate()
                }
            });
        }
        return detailsTextField;
    }
    
    public void setIsEditable( boolean isEditable)
    {
        detailsTextField.setEditable(isEditable);
        this.updateUI();
    }
    
}

