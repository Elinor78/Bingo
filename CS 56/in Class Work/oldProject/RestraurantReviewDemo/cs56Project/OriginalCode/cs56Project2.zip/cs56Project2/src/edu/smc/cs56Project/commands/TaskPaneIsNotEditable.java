/*
 * CS56 Advnced Java
 * Class: TaskPaneIsNotEditable
 * Author(s): Heather Ruderian
 * LAST UPDATE: 5-21-07
 *
 * Purpose: Encapsulates request to disable editing of TaskPane.
 * 
 */

package edu.smc.cs56Project.commands;

import edu.smc.cs56Project.gui.TaskPane;
import edu.smc.cs56Project.patterns.Command;

public class TaskPaneIsNotEditable implements Command {
    private TaskPane taskPane;
    
    public TaskPaneIsNotEditable( TaskPane tp) 
    {
        this.taskPane = tp;
    }
    
    public void execute()
    {
        taskPane.setIsEditable(false);

    }

}
