/*
 * CS56 Advanced Java
 * Interface: Observer
 * Author(s): Heather Ruderian
 * LAST UPDATE: 5-21-07
 *
 * Purpose: Interface for observer objects utilizing the Observer design pattern.
 * Observers use the update() method to register changes in a subjects state.
 */

package edu.smc.cs56Project.patterns;

public interface Observer {
    public void update( Subject s, Object arg);
}
