/*
 * CS56 Advanced Java
 * Class: NotesPanel
 * Author(s): Heather Ruderian
 * LAST UPDATE: 5-22-07
 *
 * Purpose: A panel to display visited status, last date visited, comments, 
 * directions, and map.
 * 
 * NOTE: Current implementation is for display purposes only.
 * 
 */

package edu.smc.cs56Project.gui;

import javax.swing.JPanel;
import javax.swing.JTextField;

import java.awt.FlowLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Rectangle;

public class NotesPanel extends JPanel {
    private JTextField notesTextField;
    
    // NotesPanel constructor
    public NotesPanel()
    {
        super();
        initialize();
    }
    
    // Initialize NotesPanel and add components
    private void initialize()
    {
        this.setLayout( new FlowLayout() );
        this.setPreferredSize( new Dimension( 200, 800 ) );
        this.setBounds( new Rectangle( 0, 0, 200, 800 ) );
        this.setBackground(new Color(255, 204, 153));
        this.add( getNotesTextField() );
        this.validate();
    }

    private JTextField getNotesTextField()
    {
        if (notesTextField == null) {
            notesTextField = new JTextField();
            notesTextField.setEditable(false);
            notesTextField.setFont(new Font("Arial", Font.PLAIN, 14));
            notesTextField.setText("This is the Notes Panel");
            notesTextField.addCaretListener(new javax.swing.event.CaretListener() {
                public void caretUpdate( javax.swing.event.CaretEvent e )
                {
                    System.out.println("caretUpdate()"); // TODO Auto-generated Event stub caretUpdate()
                }
            });
        }
        return notesTextField;
    }
    
    public void setIsEditable( boolean isEditable)
    {
        this.notesTextField.setEditable(isEditable);
        this.updateUI();
    }

}
