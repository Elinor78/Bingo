/*
 * CS56 Advanced Java
 * Class: ReviewTablePane
 * Author(s): Heather Ruderian
 * LAST UPDATE: 5-21-07
 *
 * Purpose: Displays a table of reviews with the following coloumns:
 * picture, restaurant name, city, food type, and overall rating.
 *
 */

package edu.smc.cs56Project.gui;

import javax.swing.JPanel;
import java.awt.Dimension;
import java.awt.Color;
import javax.swing.BorderFactory;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import java.awt.BorderLayout;
import java.awt.Font;
import javax.swing.ListSelectionModel;

public class ReviewTablePane extends JPanel {
    
    private JScrollPane reviewTableScrollPane = null;
    private JTable reviewTable = null;

    // ReviewTablePane constructor
    public ReviewTablePane()
    {
        super();
        initialize();
    }

    // Initialize ReviewTablePane and add components
    private void initialize()
    {
        this.setLayout( new BorderLayout() );
        this.setPreferredSize( new Dimension( 600, 800 ) );
        this.setBorder( BorderFactory.createLineBorder(
                new Color( 0, 153, 102 ), 5 ) );
        this.add( getReviewTableScrollPane(), BorderLayout.CENTER );

    }

    private JScrollPane getReviewTableScrollPane()
    {
        if (reviewTableScrollPane == null) {
            reviewTableScrollPane = new JScrollPane();
           // reviewTableScrollPane.setFont( new Font( "Arial", Font.PLAIN, 12 ) );
            reviewTableScrollPane.setViewportView( getReviewTable() );
        }
        return reviewTableScrollPane;
    }

    // Get table for displaying data
    // TODO Implement as an AbstractTableModele()
    private JTable getReviewTable()
    {
        String[] columnNames = { "Picture", "Name", "Location", "Food Type",
                "Rating" };
        Object[][] rowData = {
                { "Picture1", "Restaurant1", "City1, State1, Country1",
                        "Type1", "Rating1" },
                { "Picture2", "Restaurant2", "City2, State2, Country2",
                        "Type2", "Rating2" },
                { "Picture3", "Restaurant3", "City3, State3, Country3",
                        "Type3", "Rating3" },
                { "Picture4", "Restaurant4", "City4, State4, Country4",
                        "Type4", "Rating4" },
                { "Picture5", "Restaurant5", "City5, State5, Country5",
                        "Type5", "Rating5" },
                { "Picture6", "Restaurant6", "City6, State6, Country6",
                        "Type6", "Rating6" } };
        if (reviewTable == null) {
            reviewTable = new JTable( rowData, columnNames );
            reviewTable.setBackground( new Color( 204, 255, 204 ) );
            reviewTable.setRowHeight( 50 );
            reviewTable.setSelectionMode(ListSelectionModel.SINGLE_INTERVAL_SELECTION);
            reviewTable.setFont( new Font( "Arial", Font.PLAIN, 14 ) );
        }
        return reviewTable;
    }

}
