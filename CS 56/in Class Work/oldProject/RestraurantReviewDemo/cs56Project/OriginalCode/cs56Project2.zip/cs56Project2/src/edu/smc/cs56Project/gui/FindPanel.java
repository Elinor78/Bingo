/*
 * CS56 Advanced Java
 * Class: FindPanel
 * Author(s): Heather Ruderian
 * LAST UPDATE: 5-21-07
 *
 * Purpose: Displays fields for specifying search parameters. These fields
 * include: restaurant name, city, food type, and overall rating,
 *
 */

package edu.smc.cs56Project.gui;

import java.awt.FlowLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Rectangle;

import javax.swing.JPanel;
import javax.swing.JTextField;

public class FindPanel extends JPanel {
    private JTextField findTextField = null;
    
    // FindPanel constructor
    public FindPanel()
    {
        super();
        initialize();
    }
    
    // Initialize FindPanel and add components
    private void initialize()
    {
        this.setLayout( new FlowLayout() );
        this.setPreferredSize( new Dimension( 200, 800 ) );
        this.setBounds( new Rectangle( 0, 0, 200, 800 ) );
        this.setBackground(new Color(255, 204, 153));
        this.add( getFindTextField() );
        this.validate();
    }
    private JTextField getFindTextField()
    {
        if (findTextField == null) {
            findTextField = new JTextField();
            findTextField.setEditable(true);
            findTextField.setFont(new Font("Arial", Font.PLAIN, 14));
            findTextField.setText("This is the Find Panel");
        }
        return findTextField;
    }
}
