/*
 * CS56 Advanced Java
 * Class: TaskPaneIsEditable
 * Author(s): Heather Ruderian
 * LAST UPDATE: 5-21-07
 *
 * Purpose: Encapsulates request to edit TaskPane.
 * 
 */

package edu.smc.cs56Project.commands;

import edu.smc.cs56Project.patterns.*;
import edu.smc.cs56Project.database.*;

public class SearchForData implements Command, Observer {
    private String[] searchString;
    private int searchType;
    private DBStatements dbStatements;
            
    public SearchForData( DBStatements dbs ) 
    {
        this.dbStatements = dbs;
    }
    
    public void execute()
    {
     //   dbStatements.find(int tos, String values[]);
    }
    
    public void update( Subject s, Object args )
    {
        
    }

}
