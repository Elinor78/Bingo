/*
 * CS56 Advanced Java
 * Class: TaskPaneIsEditable
 * Author(s): Heather Ruderian
 * LAST UPDATE: 5-21-07
 *
 * Purpose: Encapsulates request to edit TaskPane.
 * 
 * NOTE:  In progress...do not rely on the actions of this class...
 * 
 */

package edu.smc.cs56Project.commands;
import edu.smc.cs56Project.patterns.*;
import edu.smc.cs56Project.database.*;
import edu.smc.cs56Project.gui.TaskPane;

public class SearchForData implements Command, NotifyConstants {
    private dbstatements dbstatements;
    private TaskPane taskPane;
            
    public SearchForData( dbstatements dbs, TaskPane tp ) 
    {
        this.dbstatements = dbs;
        this.taskPane = tp;
    }
    
    public void execute()
    {
        dbstatements.update(taskPane, PANEL_UPDATE);
        /*        
        try {
            dbstatements.find(taskPane.getFindPanel.getSearchParam());
            System.out.println("Search Complete!");
        } 
        catch( SQLException sql ) {
            sql.printStackTrace();
        }
        */
        System.out.println("Search command executed");
    }        
}