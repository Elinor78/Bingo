/*
 * CS56 Advanced Java
 * Class: ProjectDriver
 * Author(s): Heather Ruderian
 * LAST UPDATE: 5-29-07
 *
 * Purpose: Initializes, manages, and runs the Project code.
 *
 */

package edu.smc.cs56Project.drivers;

import java.awt.BorderLayout;
import java.awt.Container;
import java.awt.Dimension;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;

import javax.swing.JFrame;

import edu.smc.cs56Project.commands.*;
import edu.smc.cs56Project.database.dbstatements;
import edu.smc.cs56Project.gui.*;

public class ProjectDriver extends JFrame implements CommandConstants {
    private dbstatements dbstatements = null;
    private ReviewTablePane reviewTablePane = null;
    private TaskPane taskPane = null;
    private ButtonPane buttonPane = null;
    
    // ProjectDriver constructor
    public ProjectDriver()
    {
        super("ProjectDriver");
        
        initialize();
    }
    
    // Initialize ProjectDriver and add objects
    private void initialize()
    {
        dbstatements = new dbstatements();
        dbstatements.connectToDB();
        dbstatements.giveMeAll();
        
        reviewTablePane = new ReviewTablePane(dbstatements);
        taskPane = new TaskPane();
        buttonPane = new ButtonPane();
        
        // Initialize command objects
        EnableEditMode enableEditMode = new EnableEditMode(taskPane);
        DisableEditMode disableEditMode = new DisableEditMode(taskPane, dbstatements);
        SearchForData searchForData = new SearchForData( dbstatements, taskPane );
        AddData addData = new AddData( dbstatements, taskPane );
        DeleteData deleteData = new DeleteData( dbstatements, taskPane );
        DisplayAllData displayAllData = new DisplayAllData( dbstatements, taskPane );

        // Set command objects
        buttonPane.setCommand(EDIT_TRUE, enableEditMode);
        buttonPane.setCommand(EDIT_FALSE, disableEditMode);
        buttonPane.setCommand(SEARCH, searchForData);
        buttonPane.setCommand(ADD, addData);
        buttonPane.setCommand(DELETE, deleteData);
        buttonPane.setCommand(DISPLAY_ALL, displayAllData);
        
        // Register observers
        taskPane.registerObserver(buttonPane);
        taskPane.registerObserver(dbstatements);
        dbstatements.registerObserver( taskPane );
        
        // Set up JFrame
        Container container = getContentPane();
        container.add( buttonPane, BorderLayout.SOUTH );
        container.add( reviewTablePane, BorderLayout.CENTER );
        container.add( taskPane, BorderLayout.WEST );
        container.validate();

        this.setMinimumSize( new Dimension( 600, 80 ) );
        this.setSize( new Dimension( 900, 600 ) );
        this.setMinimumSize( new Dimension( 600, 400 ) );
        this.setResizable( true );
        this.setPreferredSize( new Dimension( 900, 600 ) );
        this.setVisible( true );
        this.setDefaultCloseOperation( DISPOSE_ON_CLOSE);
        this.addWindowListener( 
            new WindowAdapter() {
                public void windowClosed( WindowEvent event )
                {
                    dbstatements.disconnectFromDB();
                    System.exit( 0 );
                }
            } );
    }

    public static void main( String[] args )
    {
        new ProjectDriver();
    }

}
