package edu.smc.cs56Project.commands;

public interface NotifyConstants {
    public final static int TAB_UPDATE = 0;
    public final static int PANEL_UPDATE = 1;
    public final static int DATA_UPDATE = 3;
}
