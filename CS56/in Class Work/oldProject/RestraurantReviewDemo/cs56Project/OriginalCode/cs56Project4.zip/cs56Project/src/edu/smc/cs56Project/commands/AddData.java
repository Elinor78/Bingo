package edu.smc.cs56Project.commands;

import edu.smc.cs56Project.database.dbstatements;
import edu.smc.cs56Project.gui.TaskPane;
import edu.smc.cs56Project.patterns.Command;

public class AddData implements Command, NotifyConstants {
    private dbstatements dbstatements;
    private TaskPane taskPane;
    
    public AddData( dbstatements dbs, TaskPane tp )
    {
        this.dbstatements = dbs;
        this.taskPane = tp;
    }
    
    public void execute()
    {
        dbstatements.update(taskPane, PANEL_UPDATE);
        /*
        try {
            dbstatements.connectToDD();
            dbstatements.newEntry();
        } 
        catch( SQLException sql ) {
            sql.printStackTrace();
        }
        */
        System.out.println( "Add command executed" ); 

    }

}
