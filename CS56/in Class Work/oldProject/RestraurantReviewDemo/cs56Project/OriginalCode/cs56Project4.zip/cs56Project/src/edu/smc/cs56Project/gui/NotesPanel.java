/*
 * CS56 Advanced Java
 * Class: NotesPanel
 * Author(s): Heather Ruderian
 * LAST UPDATE: 5-25-07
 *
 * Purpose: A panel to display visited status, last date visited, comments, 
 * directions, and map.
 * 
 * NOTE: Current implementation is for display purposes only.
 * 
 */

package edu.smc.cs56Project.gui;

import javax.swing.JPanel;
import java.awt.Component;
import java.awt.FlowLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Rectangle;
import javax.swing.JCheckBox;
import javax.swing.JLabel;
import javax.swing.JTextArea;

import edu.smc.cs56Project.patterns.*;

import java.awt.GridBagLayout;
import java.util.ArrayList;

public class NotesPanel extends JPanel implements Subject, Observer {
    private ArrayList<Component> components;
    private ArrayList<Observer> observers;
    
    private JCheckBox visitedCheckBox = null;
    private JLabel commentsLabel = null;
    private JTextArea commentsTextArea = null;
    private JLabel mapLabel = null;
    private JPanel mapPanel = null;
    private JLabel directionsLabel = null;
    private JTextArea directionsTextArea = null;
    
    // NotesPanel constructor
    public NotesPanel()
    {
        super();
        components = new ArrayList<Component>();
        observers = new ArrayList<Observer>();
        initialize();
    }
    
    // Initialize NotesPanel and add components
    private void initialize()
    {
        directionsLabel = new JLabel();
        directionsLabel.setPreferredSize(new Dimension(128, 16));
        directionsLabel.setText("Directions: ");
        
        mapLabel = new JLabel();
        mapLabel.setPreferredSize(new Dimension(128, 16));
        mapLabel.setText("Map:");
        
        commentsLabel = new JLabel();
        commentsLabel.setText("Comments:");
        commentsLabel.setPreferredSize(new Dimension(128, 16));
        
        this.setLayout( new FlowLayout() );
        this.setPreferredSize( new Dimension( 200, 800 ) );
        this.setBounds( new Rectangle( 0, 0, 200, 800 ) );
        this.setBackground( new Color(255, 204, 153) );
        
        this.add( getVisitedCheckBox(), null );

        this.add(commentsLabel, null);
        this.add(getCommentsTextArea(), null);

        this.add(directionsLabel, null);
        this.add(getDirectionsTextArea(), null);

        this.add(mapLabel, null);
        this.add(getMapPanel(), null);

        this.validate();
    }

    private JCheckBox getVisitedCheckBox()
    {
        if (visitedCheckBox == null) {
            visitedCheckBox = new JCheckBox();
            visitedCheckBox.setBackground(new Color(255, 204, 153));
            visitedCheckBox.setPreferredSize(new Dimension(128, 24));
            visitedCheckBox.setText("Visited? ");
            components.add( getVisitedCheckBox() );
        }
        return visitedCheckBox;
    }

    private JTextArea getCommentsTextArea()
    {
        if (commentsTextArea == null) {
            commentsTextArea = new JTextArea();
            commentsTextArea.setPreferredSize(new Dimension(128, 118));
            components.add( getCommentsTextArea() );
        }
        return commentsTextArea;
    }

    private JTextArea getDirectionsTextArea()
    {
        if (directionsTextArea == null) {
            directionsTextArea = new JTextArea();
            directionsTextArea.setPreferredSize(new Dimension(128, 118));
            components.add( getDirectionsTextArea() );
        }
        return directionsTextArea;
    }
    
    private JPanel getMapPanel()
    {
        if (mapPanel == null) {
            mapPanel = new JPanel();
            mapPanel.setLayout(new GridBagLayout());
            mapPanel.setPreferredSize(new Dimension(128, 118));
            components.add( getMapPanel() );
        }
        return mapPanel;
    }
    
    public void setIsEditable( boolean isEditable)
    {
        for (int i = 0; i < components.size(); i++) 
            components.get(i).setEnabled( isEditable );
    }

    // Satisfy contract for Subject interface
    public void registerObserver( Observer o )
    {
        observers.add(o);
    }

    // Satisfy contract for Subject interface
    public void removeObserver( Observer o )
    {
        int i = observers.indexOf(o);
        if (i >= 0)
            observers.remove(i);
    }
 
    // Satisfy contract for Subject interface
    public void notifyObservers()
    {
        for (int i = 0; i < observers.size(); i++) {
            Observer observer = observers.get(i);
            observer.update( this, null );
        }
        
    }

    public void update( Subject s, Object arg )
    {
        // TODO Auto-generated method stub
        
    }

}
