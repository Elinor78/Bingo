/*
 * CS56 Advanced Java
 * Class: ReviewTablePane
 * Author(s): Heather Ruderian
 * LAST UPDATE: 5-21-07
 *
 * Purpose: Displays a table of reviews with the following coloumns:
 * picture, restaurant name, city, food type, and overall rating.
 *
 */

package edu.smc.cs56Project.gui;

import javax.swing.JPanel;
import java.awt.Dimension;
import java.awt.Color;
import java.awt.Font;

import javax.swing.BorderFactory;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.ListSelectionModel;
import javax.swing.ScrollPaneConstants;

import java.awt.BorderLayout;
import edu.smc.cs56Project.database.dbstatements;

public class ReviewTablePane extends JPanel {
    
    private JScrollPane reviewTableScrollPane = null;
    private JTable reviewTable = null;
    
    private dbstatements dbs;    // TODO watch this

    // ReviewTablePane constructor
    public ReviewTablePane(dbstatements dbstatements)
    {
        super();
        dbs = dbstatements; // TODO watch this
        initialize();
    }

    // Initialize ReviewTableP ane and add components
    private void initialize()
    {
        this.setLayout( new BorderLayout() );
        this.setPreferredSize( new Dimension( 600, 800 ) );
        this.setBorder( BorderFactory.createLineBorder(
                new Color( 0, 153, 102 ), 5 ) );
        this.add( getReviewTableScrollPane(), BorderLayout.CENTER );

    }

    private JScrollPane getReviewTableScrollPane()
    {
        if (reviewTableScrollPane == null) {
            reviewTableScrollPane = new JScrollPane(null, 
                    ScrollPaneConstants.VERTICAL_SCROLLBAR_AS_NEEDED, 
                    ScrollPaneConstants.HORIZONTAL_SCROLLBAR_NEVER);
            reviewTableScrollPane.setViewportView( getReviewTable(dbs) );
        }
        return reviewTableScrollPane;
    }


    // Get table for displaying data
    private JTable getReviewTable(dbstatements dbs)
    {
            reviewTable = new JTable( dbs );
            reviewTable.setBackground( new Color( 204, 255, 204 ) );
            reviewTable.setRowHeight( 50 );
            reviewTable.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
            reviewTable.getTableHeader().setReorderingAllowed(false);
            reviewTable.setFont( new Font( "Arial", Font.PLAIN, 14 ) );
        
        return reviewTable;
    }

}
