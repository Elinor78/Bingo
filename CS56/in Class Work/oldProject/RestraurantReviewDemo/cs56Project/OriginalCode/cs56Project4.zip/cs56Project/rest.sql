drop database if exists restaurants;

create database restaurants;

use restaurants;

create table rests (
  id integer unsigned auto_increment primary key,
  name varchar(50),
  city varchar(50),
  state char(2),
  zip integer,
  rating smallint,
  foodType varchar(30)
);

insert into rests (name, city,state,zip,foodType,rating) values ('The Bombay Cafe', 'Los Angeles', 'CA', 90017, 'Indian', 4);
insert into rests (name, city,state,zip,foodType,rating) values ('El Cholo', 'Santa Monica', 'CA', 90403, 'Mexican', 4);
insert into rests (name, city,state,zip,foodType,rating) values ('The Velocity Cafe', 'Venice', 'CA', 90027, 'Coffee', 3);
insert into rests (name, city,state,zip,foodType,rating) values ('California Pizza Kitchen', 'Santa Monica', 'CA', 90017, 'Pizza', 3);
insert into rests (name, city,state,zip,foodType,rating) values ('Abbots', 'Santa Monica', 'CA', 90404, 'Pizza', 3);
insert into rests (name, city,state,zip,foodType,rating) values ('Marmalades', 'Malibu', 'CA', 90265, 'French', 4);
insert into rests (name, city,state,zip,foodType,rating) values ('Coogi', 'Malibu', 'CA', 90265, 'American', 2);
insert into rests (name, city,state,zip,foodType,rating) values ('Wolfgang Pucks', 'Los Angeles', 'CA', 90017, 'Californian', 3);
insert into rests (name, city,state,zip,foodType,rating) values ('Cholada', 'Malibu', 'CA', 90265, 'Thai', 4);
insert into rests (name, city,state,zip,foodType,rating) values ('Ts Thai', 'Santa Monica', 'CA', 90403, 'Thai', 3);
insert into rests (name, city,state,zip,foodType,rating) values ('Good Stuff', 'Los Angeles', 'CA', 90017, 'American', 3);
insert into rests (name, city,state,zip,foodType,rating) values ('Dennys', '', 'CO', 80007, 'Diner', 2);
insert into rests (name, city,state,zip,foodType,rating) values ('Norms', 'Santa Monica', 'CA', 90017, 'Diner', 3);
