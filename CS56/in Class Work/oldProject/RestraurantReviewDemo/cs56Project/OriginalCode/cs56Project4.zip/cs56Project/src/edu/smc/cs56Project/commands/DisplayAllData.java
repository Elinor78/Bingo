package edu.smc.cs56Project.commands;

import edu.smc.cs56Project.database.dbstatements;
import edu.smc.cs56Project.gui.TaskPane;
import edu.smc.cs56Project.patterns.Command;


public class DisplayAllData implements Command, NotifyConstants {
    private dbstatements dbstatements;
    private TaskPane taskPane;
    
    public DisplayAllData( dbstatements dbs, TaskPane tp)
    {
        this.dbstatements = dbs;
        this.taskPane = tp;
    }
    public void execute()
    {
        dbstatements.update(taskPane, PANEL_UPDATE);
        /*
        try {
            dbstatements.connectToDD();
            dbstatements.giveMeAll();
        } 
        catch( SQLException sql ) {
            sql.printStackTrace();
        }
        */
        System.out.println( "Display all data executed" ); 

    }

}
