package edu.smc.cs56Project.gui;

import javax.swing.JPanel;
import javax.swing.JButton;
import java.awt.Dimension;
import java.awt.Color;
import java.awt.FlowLayout;
import java.awt.Rectangle;
import java.awt.Font;
import java.awt.BorderLayout;
import javax.swing.BorderFactory;
import javax.swing.JToggleButton;

public class ActionButtonPanel extends JPanel {

    private static ActionButtonPanel ABP_INSTANCE = new ActionButtonPanel();
   
    private JToggleButton editToggleButton = null;
    private JButton searchButton = null;
    private JPanel taskButtonsPanel = null;
    private JPanel listButtonsPanel = null;
    private JButton addButton = null;
    private JButton deleteButton = null;
    private JPanel DisplayButtonPanel = null;
    private JButton DisplayButton = null;
    
    private ActionButtonPanel()
    {
        super();
        this.initialize();
    }

    private void initialize()
    {
        this.setLayout( new BorderLayout() );
        this.setPreferredSize( new Dimension( 900, 50 ) );
        this.setBorder( BorderFactory.createLineBorder(
                new Color( 0, 102, 153 ), 5 ) );
        this.setBackground( new Color( 204, 255, 255 ) );
        this.setBounds( new Rectangle( 0, 0, 900, 50 ) );
        this.add( getTaskButtonsPanel(), BorderLayout.WEST );
        this.add( getDisplayButtonPanel(), BorderLayout.EAST );
        this.add( getListButtonsPanel(), BorderLayout.CENTER );
    }
    
    private JPanel getTaskButtonsPanel()
    {
        if (taskButtonsPanel == null) {
            FlowLayout flowLayout1 = new FlowLayout();
            flowLayout1.setAlignment( java.awt.FlowLayout.LEFT );
            flowLayout1.setHgap( 3 );
            taskButtonsPanel = new JPanel();
            taskButtonsPanel.setLayout( flowLayout1 );
            taskButtonsPanel.setBackground( new Color( 153, 204, 255 ) );
            taskButtonsPanel.setPreferredSize( new Dimension( 200, 35 ) );
            taskButtonsPanel.add(getEditToggleButton(), null);
            taskButtonsPanel.add(getSearchButton(), null);
        }
        return taskButtonsPanel;
    }
    
    public JToggleButton getEditToggleButton()
    {
        if (editToggleButton == null) {
            editToggleButton = new JToggleButton();
            editToggleButton.setText("Edit");
            editToggleButton.setFont(new Font("Arial", Font.PLAIN, 12));
            editToggleButton.setPreferredSize(new Dimension(80, 23));
            editToggleButton.addActionListener( new java.awt.event.ActionListener() {
                public void actionPerformed( java.awt.event.ActionEvent e )
                {
                    if (editToggleButton.isSelected()) {
                        NotesPanel.getInstance().setNotesPanel(NotesPanel.EDIT);
                        DetailsPanel.getInstance().setDetailsPanel( DetailsPanel.EDIT );
                    }
                    else {
                        NotesPanel.getInstance().setNotesPanel(NotesPanel.VIEW);
                        DetailsPanel.getInstance().setDetailsPanel( DetailsPanel.VIEW );
                    }
                    // TODO Tie action to ListPanel
                }
            } );
        }
        return editToggleButton;
    }

    public JButton getSearchButton()
    {
        if (searchButton == null) {
            searchButton = new JButton();
            searchButton.setText( "Search" );
            searchButton.setFont( new Font( "Arial", Font.PLAIN, 12 ) );
            searchButton.setPreferredSize( new Dimension( 80, 23 ) );
            searchButton.addActionListener( new java.awt.event.ActionListener() {
                public void actionPerformed( java.awt.event.ActionEvent e )
                {
                    System.out.println( "actionPerformed()" ); 
                    // TODO Tie action to TabsPanel and ListPanel
                }
            } );
        }
        return searchButton;
    }

    private JPanel getListButtonsPanel()
    {
        if (listButtonsPanel == null) {
            FlowLayout flowLayout = new FlowLayout();
            flowLayout.setAlignment( java.awt.FlowLayout.LEFT );
            flowLayout.setHgap( 3 );
            listButtonsPanel = new JPanel();
            listButtonsPanel.setLayout( flowLayout );
            listButtonsPanel.setPreferredSize( new Dimension( 200, 35 ) );
            listButtonsPanel.setBackground( new Color( 153, 153, 255 ) );
            listButtonsPanel.add( getAddButton(), null );
            listButtonsPanel.add( getDeleteButton(), null );
        }
        return listButtonsPanel;
    }

    private JButton getAddButton()
    {
        if (addButton == null) {
            addButton = new JButton();
            addButton.setText( "Add" );
            addButton.setFont( new Font( "Arial", Font.PLAIN, 12 ) );
            addButton.setPreferredSize( new Dimension( 80, 23 ) );
            addButton.addActionListener( new java.awt.event.ActionListener() {
                public void actionPerformed( java.awt.event.ActionEvent e )
                {
                    System.out.println( "actionPerformed()" ); 
                    // TODO Tie action to ListPanel and TabsPanel
                }
            } );
        }
        return addButton;
    }

    private JButton getDeleteButton()
    {
        if (deleteButton == null) {
            deleteButton = new JButton();
            deleteButton.setText( "Delete" );
            deleteButton.setFont( new Font( "Arial", Font.PLAIN, 12 ) );
            deleteButton.setPreferredSize( new Dimension( 80, 23 ) );
            deleteButton.addActionListener( new java.awt.event.ActionListener() {
                public void actionPerformed( java.awt.event.ActionEvent e )
                {
                    System.out.println( "actionPerformed()" ); 
                    // TODO Tie action to ListPanel and TabsPanel
                }
            } );
        }
        return deleteButton;
    }

    private JPanel getDisplayButtonPanel()
    {
        if (DisplayButtonPanel == null) {
            FlowLayout flowLayout2 = new FlowLayout();
            flowLayout2.setHgap( 3 );
            flowLayout2.setAlignment( java.awt.FlowLayout.RIGHT );
            DisplayButtonPanel = new JPanel();
            DisplayButtonPanel.setBackground( new Color( 102, 102, 255 ) );
            DisplayButtonPanel.setLayout( flowLayout2 );
            DisplayButtonPanel.setPreferredSize( new Dimension( 200, 35 ) );
            DisplayButtonPanel.add( getDisplayButton(), null );
        }
        return DisplayButtonPanel;
    }

    private JButton getDisplayButton()
    {
        if (DisplayButton == null) {
            DisplayButton = new JButton();
            DisplayButton.setText( "Display All" );
            DisplayButton.setFont( new Font( "Arial", Font.PLAIN, 12 ) );
            DisplayButton.setPreferredSize(new Dimension(100, 23));
            DisplayButton.addActionListener( new java.awt.event.ActionListener() {
                public void actionPerformed( java.awt.event.ActionEvent e )
                {
                    System.out.println( "actionPerformed()" ); 
                    // TODO Tie action to ListPanel and TabsPanel
                }
            } );
        }
        return DisplayButton;
    }
    
    public static ActionButtonPanel getInstance()
    {
        return ABP_INSTANCE;
    }

}