package edu.smc.cs56Project.gui;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Rectangle;

import javax.swing.JPanel;

public class FindPanel extends JPanel {
    
    private static FindPanel FP_INSTANCE = new FindPanel();
    
    
    private FindPanel()
    {
        super();
        initialize();
    }
    
    private void initialize()
    {
        this.setLayout( new BorderLayout() );
        this.setPreferredSize( new Dimension( 200, 800 ) );
        this.setBounds( new Rectangle( 0, 0, 200, 800 ) );
        this.setBackground(new Color(255, 153, 0));
        this.validate();
    }
    
    public static FindPanel getInstance()
    {
        return FP_INSTANCE;
    }

}
