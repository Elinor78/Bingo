package edu.smc.cs56Project.gui;
import java.awt.Container;

import javax.swing.JFrame;


import java.awt.BorderLayout;
import java.awt.Dimension;

public class GUIDriver extends JFrame {

    public GUIDriver()
    {
        super("GUIDriver");
        initialize();
    }

    private void initialize()
    {
        ListPanel listPanel = ListPanel.getInstance();
        TabsPanel tabsPanel = TabsPanel.getInstance();
        ActionButtonPanel actionButtonPanel = ActionButtonPanel.getInstance();

        Container container = getContentPane();
        container.add( actionButtonPanel, BorderLayout.SOUTH );
        container.add( listPanel, BorderLayout.CENTER );
        container.add( tabsPanel, BorderLayout.WEST );
        container.validate();

        this.setMinimumSize( new Dimension( 600, 80 ) );
        this.setSize( new Dimension( 900, 600 ) );
        this.setMinimumSize( new Dimension( 600, 400 ) );
        this.setResizable( true );
        this.setPreferredSize( new Dimension( 900, 600 ) );
        this.setVisible( true );
    }

    public static void main( String[] args )
    {
     
        GUIDriver guiDriver = new GUIDriver();
        guiDriver.setDefaultCloseOperation( JFrame.EXIT_ON_CLOSE );
    }

}
