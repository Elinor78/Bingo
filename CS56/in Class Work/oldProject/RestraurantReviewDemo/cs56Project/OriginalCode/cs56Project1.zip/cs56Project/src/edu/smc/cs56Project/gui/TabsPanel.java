package edu.smc.cs56Project.gui;

import javax.swing.JPanel;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import javax.swing.JTabbedPane;
import java.awt.Rectangle;
import java.awt.Font;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;

public class TabsPanel extends JPanel {

    private static TabsPanel TP_INSTANCE = new TabsPanel();
    
    // Use this field with the ChangeListener
    //private static final String FIND = "Find";
    
    private JTabbedPane tasksTabbedPane = null;

    private TabsPanel()
    {
        super();
        initialize();
    }

    private void initialize()
    {
        this.setLayout( new BorderLayout() );
        this.setPreferredSize( new Dimension( 200, 800 ) );
        this.setBounds( new Rectangle( 0, 0, 200, 800 ) );
        this.setBackground( new Color( 255, 204, 204 ) );
        this.add( getTasksTabbedPane(), BorderLayout.CENTER );
    }

    private JTabbedPane getTasksTabbedPane()
    {
        if (tasksTabbedPane == null) {
            tasksTabbedPane = new JTabbedPane();
            tasksTabbedPane.setTabPlacement( JTabbedPane.BOTTOM );
            tasksTabbedPane.setPreferredSize( new Dimension( 200, 800 ) );
            tasksTabbedPane.setFont( new Font( "Arial", Font.PLAIN, 12 ) );
            tasksTabbedPane.setBackground( new Color( 255, 255, 204 ) );
            tasksTabbedPane.addTab( "Details", null, getDetailsPanel(), null );
            tasksTabbedPane.addTab( "Notes", null, getNotesPanel(), null );
            tasksTabbedPane.addTab( "Find", null, getFindPanel(), null );
            tasksTabbedPane.addChangeListener(new ChangeListener() {
                public void stateChanged(ChangeEvent changeEvent) {
                    // TODO Fix ChangeListener
                    /*
                    JTabbedPane sourceTabbedPane = (JTabbedPane) changeEvent.getSource();
                    int tabIndex = sourceTabbedPane.getSelectedIndex();
                    if (sourceTabbedPane.getTitleAt( tabIndex ) == FIND ) {
                        ActionButtonPanel.getInstance().getEditToggleButton().setEnabled( false );
                        ActionButtonPanel.getInstance().getSearchButton().setEnabled( true );
                    }
                    else {
                        ActionButtonPanel.getInstance().getEditToggleButton().setEnabled( true );
                        ActionButtonPanel.getInstance().getSearchButton().setEnabled( false );
                    } 
                    */
                }
            });
        }
        return tasksTabbedPane;
    }

    private JPanel getDetailsPanel()
    {
        return DetailsPanel.getInstance();
    }

    private NotesPanel getNotesPanel()
    {
        return NotesPanel.getInstance();
    }

    private JPanel getFindPanel()
    {
        return FindPanel.getInstance();
    }
    
    public static TabsPanel getInstance()
    {
        return TP_INSTANCE;
        
    }

}
