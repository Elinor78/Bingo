package edu.smc.cs56Project.gui;

import javax.swing.JPanel;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Rectangle;

public class NotesPanel extends JPanel {
    
    private static NotesPanel NP_INSTANCE = new NotesPanel();
    
    public static final int VIEW = 0;
    public static final int EDIT = 1;
    
    private NotesPanel()
    {
        super();
        initialize();
    }
    
    private void initialize()
    {
        this.setLayout( new BorderLayout() );
        this.setPreferredSize( new Dimension( 200, 800 ) );
        this.setBounds( new Rectangle( 0, 0, 200, 800 ) );
        this.setBackground(Color.yellow);
        this.add( getViewNotesPanel() );
        this.validate();
    }
    
    private ViewNotesPanel getViewNotesPanel()
    {
        return ViewNotesPanel.getInstance();
    }
    
    private EditNotesPanel getEditNotesPanel()
    {
        return EditNotesPanel.getInstance();
    }
    
    public void setNotesPanel( int viewStyle)
    {
        if (viewStyle == EDIT) {
            this.remove( getViewNotesPanel() );
            this.add( getEditNotesPanel() );
        }
        else if (viewStyle == VIEW) {
            this.remove( getEditNotesPanel() );
            this.add( getViewNotesPanel() );
        }
        this.validate();        // TODO Check if validate is necessary
        this.updateUI();
    }
    
    public static NotesPanel getInstance()
    {
        return NP_INSTANCE;
    }
}
