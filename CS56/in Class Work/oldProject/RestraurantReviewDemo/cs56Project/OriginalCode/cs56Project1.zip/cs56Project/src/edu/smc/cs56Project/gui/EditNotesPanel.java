package edu.smc.cs56Project.gui;

import javax.swing.JPanel;
import java.awt.GridBagLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Rectangle;
import javax.swing.JTextField;
import java.awt.GridBagConstraints;
import java.awt.Font;

public class EditNotesPanel extends JPanel {
    
    private static EditNotesPanel ENP_INSTANCE = new EditNotesPanel();
    
    private JTextField panelTextField = null;

    private EditNotesPanel()
    {
        super();
        initialize();
    }
    
    private void initialize()
    {
        GridBagConstraints gridBagConstraints = new GridBagConstraints();
        gridBagConstraints.fill = GridBagConstraints.VERTICAL;
        gridBagConstraints.gridy = 0;
        gridBagConstraints.weightx = 1.0;
        gridBagConstraints.gridx = 0;
        this.setLayout( new GridBagLayout() );
        this.setPreferredSize( new Dimension( 200, 800 ) );
        this.setBounds( new Rectangle( 0, 0, 200, 800 ) );
        this.setBackground( new Color( 255, 204, 102 ) );
        this.add(getPanelTextField(), gridBagConstraints);
    }

    private JTextField getPanelTextField()
    {
        if (panelTextField == null) {
            panelTextField = new JTextField();
            panelTextField.setFont(new Font("Arial", Font.PLAIN, 14));
            panelTextField.setText("This is the Edit Notes Panel");
        }
        return panelTextField;
    }
    
    public static EditNotesPanel getInstance()
    {
        return ENP_INSTANCE;
    }
}
