package edu.smc.cs56Project.gui;

import javax.swing.JPanel;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Rectangle;

public class DetailsPanel extends JPanel {
    
    private static DetailsPanel DP_INSTANCE = new DetailsPanel();
    
    public static final int VIEW = 0;
    public static final int EDIT = 1;
    
    private DetailsPanel()
    {
        super();
        initialize();
    }
    
    private void initialize()
    {
        this.setLayout( new BorderLayout() );
        this.setPreferredSize( new Dimension( 200, 800 ) );
        this.setBounds( new Rectangle( 0, 0, 200, 800 ) );
        this.setBackground(new Color(204, 255, 0));
        this.add( getViewDetailsPanel() );
        this.validate();
    }
    
    private ViewDetailsPanel getViewDetailsPanel()
    {
        return ViewDetailsPanel.getInstance();
    }
    
    private EditDetailsPanel getEditDetailsPanel()
    {
        return EditDetailsPanel.getInstance();
    }
    
    public void setDetailsPanel( int viewStyle)
    {
        if (viewStyle == EDIT) {
            this.remove( getViewDetailsPanel() );
            this.add( getEditDetailsPanel() );
        }
        else if (viewStyle == VIEW) {
            this.remove( getEditDetailsPanel() );
            this.add( getViewDetailsPanel() );
        }
        this.validate();        // TODO Check if validate is necessary
        this.updateUI();
    }
        
    public static DetailsPanel getInstance()
    {
        return DP_INSTANCE;
    }
}

